# import pandas as pd
# from sklearn.linear_model import LinearRegression

# # # load the datasets

# df1 = pd.read_csv("data.csv")  # County,Percent,MeanCM,MeanS, NDVI,Temp



# # # convert raw MODIS LST values to Fahrenheit
# # def modis_raw_to_fahrenheit(raw_val):
# #     kelvin = raw_val * 0.02
# #     celsius = kelvin - 273.15
# #     fahrenheit = celsius * 9/5 + 32
# #     return fahrenheit

# # # add new column
# # df2['mean'] = df2['mean'].apply(modis_raw_to_fahrenheit)

# # # overwrite the original CSV file with the new column added
# # #df2.to_csv("temp.csv", index=False)




# # # keep only rows in df2 where NAME exists in df1["County"]
# # df2 = df2[df2["NAME"].isin(df1["County"])]
# # df2.to_csv("temp.csv", index=False)



# #  # sort by the "County" column alphabetically
# # df2 = df2.sort_values(by="NAME")

# # # # if you want to save it
# # df2.to_csv("temp.csv", index=False)
# # #Imports
import pandas as pd
import seaborn as sns
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# load your merged data
data = pd.read_csv("data.csv")

# regression scatter plot
sns.set(style="whitegrid")
plot = sns.lmplot(
    x="MeanSD",
    y="MeanCM",
    data=data,
    height=6,
    aspect=1.2,
    scatter_kws={"color": "purple"},
    line_kws={"color": "black"}
)

# labels and title
plt.title("Carbon monoxide vs Sulfur Dioxide with Trendline")
plt.xlabel("Sulfur Dioxide")
plt.ylabel("Carbon monoxide")
plt.tight_layout()

# save to file
plot.savefig("scatterplot_with_line.png")
print("scatterplot with line saved as 'scatterplot_with_line.png'")






# import pandas as pd
# import statsmodels.api as sm
# import matplotlib.pyplot as plt
# import seaborn as sns

# # =========================
# # STEP 1: load data
# # =========================
# df = pd.read_csv("data.csv")  # replace with your file name

# # optional: check columns
# print(df.columns)

# # =========================
# # STEP 2: drop missing values
# # =========================
# df = df.dropna()

# # =========================
# # STEP 3: define predictors (X) and target (y)
# # =========================
# # we are now predicting CO based on environmental and demographic variables
# X = df[["Percent", "NDVI", "Temp", "MeanSD", "Poverty"]]
# y = df["MeanCM"]  # ← this is your CO column, right?

# # =========================
# # STEP 4: add constant term
# # =========================
# X = sm.add_constant(X)

# # =========================
# # STEP 5: build and run the model
# # =========================
# model = sm.OLS(y, X).fit()

# # =========================
# # STEP 6: print summary
# # =========================
# print(model.summary())

# # =========================
# # STEP 7: visualize predicted vs actual
# # =========================
# df["predicted_CO"] = model.predict(X)

# sns.scatterplot(x=df["MeanCM"], y=df["predicted_CO"])
# plt.xlabel("Actual CO")
# plt.ylabel("Predicted CO")
# plt.title("Predicted vs Actual CO")
# plt.plot([df["MeanCM"].min(), df["MeanCM"].max()],
#          [df["MeanCM"].min(), df["MeanCM"].max()],
#          color="red", linestyle="--")
# plt.tight_layout()
# plt.show()


