import pandas as pd
import statsmodels.api as sm

import matplotlib.pyplot as plt
import seaborn as sns

# =========================
# STEP 1: load your dataset
# =========================import pandas as pd
import statsmodels.api as sm
import matplotlib.pyplot as plt
import seaborn as sns

# =========================
# STEP 1: Load your dataset
# =========================
df = pd.read_csv("data.csv")  # make sure 'data.csv' has the correct column names

# =========================
# STEP 2: Define predictors (X) and target (y)
# =========================
# Predicting 'Percent' (Minority %) using NDVI, MEANSD, MEANCM, TEMP
X = df[["NDVI", "MEANSD", "MEANCM", "TEMP"]]
y = df["Percent"]

# =========================
# STEP 3: Add constant for intercept
# =========================
X = sm.add_constant(X)

# =========================
# STEP 4: Build and fit the model
# =========================
model = sm.OLS(y, X).fit()

# =========================
# STEP 5: Print model summary
# =========================
print(model.summary())

# =========================
# STEP 6: Plot predicted vs actual
# =========================
df["predicted_percent"] = model.predict(X)

plt.figure(figsize=(8, 6))
sns.scatterplot(x=df["Percent"], y=df["predicted_percent"])
plt.xlabel("Actual Minority %")
plt.ylabel("Predicted Minority %")
plt.title("Actual vs Predicted Minority Percent")

# 1:1 reference line
min_val = min(df["Percent"].min(), df["predicted_percent"].min())
max_val = max(df["Percent"].max(), df["predicted_percent"].max())
plt.plot([min_val, max_val], [min_val, max_val], color="red", linestyle="--")

plt.tight_layout()
plt.show()

df = pd.read_csv("data.csv")  # replace with your actual file


# =========================
# STEP 3: define predictors (X) and target (y)
# =========================
# we're predicting Minority_Percent using environmental factors
X = df[["NDVI", "MEANSD", "MEANCM", "TEMP"]]  # you can also try adding SO2, PM2.5, etc.
y = df["Percent"]

# =========================
# STEP 4: add constant (intercept)
# =========================
X = sm.add_constant(X)

# =========================
# STEP 5: build + run model
# =========================
model = sm.OLS(y, X).fit()

# =========================
# STEP 6: print results
# =========================
print(model.summary())

# =========================
# STEP 7: plot predictions vs actual
# =========================
df["predicted_minority"] = model.predict(X)

plt.figure(figsize=(8, 6))
sns.scatterplot(x=df["Percent"], y=df["predicted_minority"])
plt.xlabel("Actual Minority %")
plt.ylabel("Predicted Minority %")
plt.title("Actual vs Predicted Minority Percent")
plt.plot([df["Minority_Percent"].min(), df["Minority_Percent"].max()],
         [df["Minority_Percent"].min(), df["Minority_Percent"].max()],
         color="red", linestyle="--")  # 1:1 reference line
plt.tight_layout()
plt.savefig("regression_plot.png")
plt.show()
